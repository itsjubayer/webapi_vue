using Microsoft.AspNetCore.Mvc;

namespace VueApp_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {

        //https://www.youtube.com/watch?v=qS833HGKPD8
        /// <summary>
        /// code Blog:    https://art-of-engineer.blogspot.com/2021/06/net-core-web-api-vue-js-microsoft-sql.html
        /// GIT: https://github.com/ArtOfEngineer/Vue-Js-ASP-NET-Core-WebAPI
        /// </summary>


        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}